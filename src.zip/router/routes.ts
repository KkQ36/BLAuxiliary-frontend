import type {RouteRecordRaw} from "vue-router";
import UserLoginView from "@/views/user/UserLoginView.vue";


export const routes: Array<RouteRecordRaw> = [
    {
        path: "/user",
        name: "用户",
        children: [
            {
                path: "/user/login",
                component: UserLoginView,
            },
        ],
    },
]