<template>
    <div class="content">Content</div>
</template>

<script setup lang="ts">
</script>

<style scoped>
.content {
  background-image: url("@/images/userLoginBackground.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  width: 1600px;
  height: 800px;
}
</style>
